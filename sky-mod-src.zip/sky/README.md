# Sky (Fabric 1.21.4)
Меню: Right Ctrl (меняется в Управление -> Sky). Модули: FPS, координаты, клавиши, подсветка, выбор цвета (в т.ч. радужный).
Настройки сохраняются в config/sky.properties.

## Сборка
Нужен JDK 21 и интернет (при первом запуске скачаются Gradle, Minecraft и Fabric).

Windows:   gradlew.bat build
Linux/Mac: ./gradlew build

Результат: build/libs/Sky.jar. Положи в папку mods вместе с Fabric Loader и Fabric API 1.21.4.

Без установки: залей проект на GitHub, Actions соберёт Sky.jar (Actions -> build -> Artifacts).
