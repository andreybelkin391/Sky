@echo off
rem Gradle wrapper launcher. Если gradle-wrapper.jar отсутствует, скачивает его.
setlocal
set "APP_HOME=%~dp0"
set "WRAPPER_JAR=%APP_HOME%gradle\wrapper\gradle-wrapper.jar"

if exist "%WRAPPER_JAR%" goto run
echo Downloading gradle-wrapper.jar ...
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing -Uri 'https://raw.githubusercontent.com/gradle/gradle/v8.12.0/gradle/wrapper/gradle-wrapper.jar' -OutFile '%WRAPPER_JAR%'"
if errorlevel 1 goto fail
if not exist "%WRAPPER_JAR%" goto fail
goto run

:fail
echo Failed to download gradle-wrapper.jar. Check your internet connection.
del "%WRAPPER_JAR%" >nul 2>&1
exit /b 1

:run
if defined JAVA_HOME (set "JAVA_EXE=%JAVA_HOME%\bin\java.exe") else (set "JAVA_EXE=java.exe")
"%JAVA_EXE%" -Xmx64m -Xms64m -classpath "%WRAPPER_JAR%" org.gradle.wrapper.GradleWrapperMain %*
set "RC=%ERRORLEVEL%"
endlocal & exit /b %RC%
