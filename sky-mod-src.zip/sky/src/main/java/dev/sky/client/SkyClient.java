package dev.sky.client;

import dev.sky.client.gui.SkyMenu;
import dev.sky.client.module.Modules;
import dev.sky.client.render.SkyHud;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class SkyClient implements ClientModInitializer {
    private static KeyBinding menuKey;
    private static boolean tweaksApplied = false;

    @Override
    public void onInitializeClient() {
        Modules.load();
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.sky.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_CONTROL, "category.sky"));
        HudRenderCallback.EVENT.register(SkyHud::render);
        ClientTickEvents.END_CLIENT_TICK.register(SkyClient::onTick);
    }

    private static void onTick(MinecraftClient mc) {
        SkyHud.tick();
        while (menuKey.wasPressed()) {
            if (mc.currentScreen == null) mc.setScreen(new SkyMenu());
        }
        if (!tweaksApplied && mc.options != null) {
            applyPerformanceTweaks(mc);
            tweaksApplied = true;
        }
    }

    /** Безопасные настройки, снижающие нагрузку. Применяются один раз при запуске. */
    private static void applyPerformanceTweaks(MinecraftClient mc) {
        mc.options.getEntityDistanceScaling().setValue(0.75);
        mc.options.getBiomeBlendRadius().setValue(1);
        mc.options.getMipmapLevels().setValue(2);
        mc.options.getEnableVsync().setValue(false);
        mc.options.write();
    }
}
