package dev.sky.client.gui;

import dev.sky.client.module.Module;
import dev.sky.client.module.Modules;
import dev.sky.client.render.RoundedRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/** Меню Sky. Открывается/закрывается на Right Ctrl. */
public class SkyMenu extends Screen {
    private static final int W = 320, H = 214, PAD = 12, CARD_H = 38, GAP = 8;
    private static final int PANEL = 0xF0121216, CARD = 0xFF1C1C22, CARD_HOVER = 0xFF26262E;
    private static final int TEXT = 0xFFE4E4E7, SUB = 0xFF8B8B96;

    private float open = 0f;
    private long last = System.nanoTime();

    public SkyMenu() { super(Text.literal("Sky")); }

    @Override public boolean shouldPause() { return false; }

    private int left() { return (width - W) / 2; }
    private int top()  { return (height - H) / 2; }
    private int cardW() { return (W - PAD * 2 - GAP) / 2; }
    private int cardX(int i) { return left() + PAD + (i % 2) * (cardW() + GAP); }
    private int cardY(int i) { return top() + 46 + (i / 2) * (CARD_H + GAP); }
    private int swatchX(int i) { return left() + PAD + 58 + i * 22; }
    private int swatchY() { return top() + H - 30; }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta); // размытый фон

        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - last) / 1_000_000_000f);
        last = now;
        open = Math.min(1f, open + dt * 6f);
        float e = 1f - (float) Math.pow(1f - open, 3);
        float scale = 0.9f + 0.1f * e;

        int accent = Modules.accent();
        int cx = width / 2, cy = height / 2;

        ctx.getMatrices().push();
        ctx.getMatrices().translate(cx, cy, 0);
        ctx.getMatrices().scale(scale, scale, 1f);
        ctx.getMatrices().translate(-cx, -cy, 0);

        int x = left(), y = top();
        RoundedRenderer.panel(ctx, x, y, W, H, 8, PANEL, accent, true);

        ctx.drawText(textRenderer, "SKY", x + PAD, y + 12, accent, true);
        ctx.drawText(textRenderer, "Right Ctrl — закрыть", x + PAD + 30, y + 12, SUB, false);
        ctx.fill(x + PAD, y + 28, x + W - PAD, y + 29, 0x22FFFFFF);

        for (int i = 0; i < Modules.ALL.size(); i++) {
            Module m = Modules.ALL.get(i);
            int cxp = cardX(i), cyp = cardY(i), cw = cardW();
            boolean hov = inside(mouseX, mouseY, cxp, cyp, cw, CARD_H);
            m.hover += ((hov ? 1f : 0f) - m.hover) * Math.min(1f, dt * 14f);
            m.anim += ((m.enabled ? 1f : 0f) - m.anim) * Math.min(1f, dt * 14f);

            RoundedRenderer.fill(ctx, cxp, cyp, cw, CARD_H, 6,
                    RoundedRenderer.lerpColor(CARD, CARD_HOVER, m.hover));
            ctx.drawText(textRenderer, m.name, cxp + 10, cyp + 8, TEXT, false);
            ctx.drawText(textRenderer, m.desc, cxp + 10, cyp + 21, SUB, false);

            // переключатель
            int sw = 26, sh = 12, sx = cxp + cw - sw - 10, sy = cyp + (CARD_H - sh) / 2;
            RoundedRenderer.fill(ctx, sx, sy, sw, sh, 6,
                    RoundedRenderer.lerpColor(0xFF3A3A44, accent, m.anim));
            int kx = sx + 2 + Math.round((sw - sh) * m.anim);
            RoundedRenderer.fill(ctx, kx, sy + 2, sh - 4, sh - 4, 4, 0xFFFFFFFF);
        }

        // выбор цвета
        ctx.drawText(textRenderer, "Цвет", x + PAD, swatchY() + 4, SUB, false);
        for (int i = 0; i <= Modules.PALETTE.length; i++) {
            int sx = swatchX(i), sy = swatchY();
            boolean rainbow = i == Modules.PALETTE.length;
            int col = rainbow ? accentRainbow() : Modules.PALETTE[i];
            if (Modules.accentIndex == i) RoundedRenderer.fill(ctx, sx - 2, sy - 2, 18, 18, 9, 0xFFFFFFFF);
            RoundedRenderer.fill(ctx, sx, sy, 14, 14, 7, col);
        }

        ctx.getMatrices().pop();
    }

    private static int accentRainbow() {
        int old = Modules.accentIndex;
        Modules.accentIndex = Modules.PALETTE.length;
        int c = Modules.accent();
        Modules.accentIndex = old;
        return c;
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0) {
            for (int i = 0; i < Modules.ALL.size(); i++) {
                if (inside(mx, my, cardX(i), cardY(i), cardW(), CARD_H)) {
                    Modules.ALL.get(i).toggle();
                    return true;
                }
            }
            for (int i = 0; i <= Modules.PALETTE.length; i++) {
                if (inside(mx, my, swatchX(i), swatchY(), 14, 14)) {
                    Modules.accentIndex = i;
                    return true;
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_CONTROL) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void removed() { Modules.save(); }
}
