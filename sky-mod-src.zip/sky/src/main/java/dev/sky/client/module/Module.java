package dev.sky.client.module;

public class Module {
    public final String id, name, desc;
    public boolean enabled = true;
    public float anim = 1f;   // 0..1, анимация переключателя
    public float hover = 0f;  // 0..1, анимация наведения

    public Module(String id, String name, String desc) {
        this.id = id; this.name = name; this.desc = desc;
    }

    public void toggle() { enabled = !enabled; }
}
