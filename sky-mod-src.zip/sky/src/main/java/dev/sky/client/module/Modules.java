package dev.sky.client.module;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.util.math.MathHelper;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Properties;

public final class Modules {
    public static final Module FPS    = new Module("fps", "FPS", "Счётчик кадров");
    public static final Module COORDS = new Module("coords", "Координаты", "XYZ игрока");
    public static final Module KEYS   = new Module("keys", "Клавиши", "WASD на экране");
    public static final Module GLOW   = new Module("glow", "Подсветка", "Свечение панелей");
    public static final List<Module> ALL = List.of(FPS, COORDS, KEYS, GLOW);

    public static final int[] PALETTE = {
            0xFF60A5FA, 0xFF4ADE80, 0xFFF472B6, 0xFFFBBF24, 0xFFA78BFA, 0xFFF87171
    };
    /** Индекс PALETTE.length означает «радужный» режим. */
    public static int accentIndex = 0;

    private Modules() {}

    public static int accent() {
        if (accentIndex >= PALETTE.length) {
            float h = (System.currentTimeMillis() % 5000L) / 5000f;
            return 0xFF000000 | MathHelper.hsvToRgb(h, 0.55f, 1f);
        }
        return PALETTE[accentIndex];
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("sky.properties");
    }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) return;
        try (Reader r = Files.newBufferedReader(f)) {
            Properties p = new Properties();
            p.load(r);
            for (Module m : ALL) {
                m.enabled = Boolean.parseBoolean(p.getProperty(m.id, "true"));
                m.anim = m.enabled ? 1f : 0f;
            }
            accentIndex = Math.max(0, Math.min(PALETTE.length, Integer.parseInt(p.getProperty("accent", "0"))));
        } catch (IOException | NumberFormatException ignored) {}
    }

    public static void save() {
        Properties p = new Properties();
        for (Module m : ALL) p.setProperty(m.id, Boolean.toString(m.enabled));
        p.setProperty("accent", Integer.toString(accentIndex));
        try (Writer w = Files.newBufferedWriter(file())) {
            p.store(w, "Sky config");
        } catch (IOException ignored) {}
    }
}
