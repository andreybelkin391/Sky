package dev.sky.client.render;

import dev.sky.client.module.Modules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderTickCounter;

/** HUD: FPS (плавно), координаты, клавиши. Каждый блок включается в меню Sky. */
public final class SkyHud {
    private static final int BG = 0xB0141418;
    private static final int GOOD = 0xFF4ADE80;
    private static final int BAD = 0xFFF87171;

    private static float smoothFps = 0f;
    private static long tickCount = 0;
    private static String fpsLine = "", coordLine = "";
    private static final float[] keyAnim = new float[4];

    private SkyHud() {}

    public static void tick() {
        tickCount++;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        if (tickCount % 4 == 0) {
            fpsLine = Math.round(smoothFps) + " FPS";
            var p = mc.player;
            coordLine = String.format("XYZ %d %d %d", (int) p.getX(), (int) p.getY(), (int) p.getZ());
        }
    }

    public static void render(DrawContext ctx, RenderTickCounter counter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || mc.player == null || mc.getDebugHud().shouldShowDebugHud()) return;

        smoothFps += (mc.getCurrentFps() - smoothFps) * 0.08f;
        TextRenderer tr = mc.textRenderer;
        int accent = Modules.accent();
        boolean glow = Modules.GLOW.enabled;
        int x = 6, y = 6;

        if (Modules.FPS.enabled) {
            float load = Math.min(1f, Math.max(0f, 1f - smoothFps / 144f));
            int col = RoundedRenderer.lerpColor(GOOD, BAD, load);
            int w = tr.getWidth(fpsLine) + 14;
            RoundedRenderer.panel(ctx, x, y, w, 18, 4, BG, accent, glow);
            ctx.drawText(tr, fpsLine, x + 7, y + 5, col, true);
            y += 24;
        }

        if (Modules.COORDS.enabled) {
            int w = tr.getWidth(coordLine) + 14;
            RoundedRenderer.panel(ctx, x, y, w, 18, 4, BG, accent, glow);
            ctx.drawText(tr, coordLine, x + 7, y + 5, 0xFFD4D4D8, true);
            y += 24;
        }

        if (Modules.KEYS.enabled) {
            KeyBinding[] keys = {
                    mc.options.forwardKey, mc.options.leftKey, mc.options.backKey, mc.options.rightKey
            };
            String[] label = {"W", "A", "S", "D"};
            int s = 18, g = 2;
            int[][] pos = {{s + g, 0}, {0, s + g}, {s + g, s + g}, {2 * (s + g), s + g}};
            for (int i = 0; i < 4; i++) {
                keyAnim[i] += ((keys[i].isPressed() ? 1f : 0f) - keyAnim[i]) * 0.3f;
                int kx = x + pos[i][0], ky = y + pos[i][1];
                int bg = RoundedRenderer.lerpColor(BG | 0xFF000000, accent, keyAnim[i] * 0.85f);
                RoundedRenderer.fill(ctx, kx, ky, s, s, 4, (0xB0 << 24) | (bg & 0xFFFFFF));
                int tw = tr.getWidth(label[i]);
                ctx.drawText(tr, label[i], kx + (s - tw) / 2, ky + 5,
                        RoundedRenderer.lerpColor(0xFFD4D4D8, 0xFF101014, keyAnim[i]), false);
            }
        }
    }
}
