package dev.sky.client.render;

import net.minecraft.client.gui.DrawContext;

/** Скруглённые прямоугольники через построчные fill(): без шейдеров, батчится самим DrawContext. */
public final class RoundedRenderer {
    private RoundedRenderer() {}

    public static void fill(DrawContext ctx, int x, int y, int w, int h, int radius, int color) {
        int r = Math.max(0, Math.min(radius, Math.min(w, h) / 2));
        if (r == 0) { ctx.fill(x, y, x + w, y + h, color); return; }

        ctx.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
            ctx.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            ctx.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
        }
    }

    /** Панель с опциональным свечением и акцентной линией снизу. */
    public static void panel(DrawContext ctx, int x, int y, int w, int h, int radius,
                             int bg, int accent, boolean glow) {
        if (glow) {
            fill(ctx, x - 2, y - 2, w + 4, h + 4, radius + 2, withAlpha(accent, 0.10f));
            fill(ctx, x - 1, y - 1, w + 2, h + 2, radius + 1, withAlpha(accent, 0.22f));
        } else {
            fill(ctx, x - 1, y - 1, w + 2, h + 2, radius + 1, 0x40000000);
        }
        fill(ctx, x, y, w, h, radius, bg);
        fill(ctx, x + 4, y + h - 2, w - 8, 1, 0, accent);
    }

    public static int withAlpha(int color, float a) {
        int alpha = (int) (Math.max(0f, Math.min(1f, a)) * 255f);
        return (alpha << 24) | (color & 0x00FFFFFF);
    }

    public static int lerpColor(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = (int) ((a >> 16 & 255) + ((b >> 16 & 255) - (a >> 16 & 255)) * t);
        int g = (int) ((a >> 8 & 255) + ((b >> 8 & 255) - (a >> 8 & 255)) * t);
        int bl = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }
}
